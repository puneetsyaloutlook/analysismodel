# Steps 7 and 8: choose conclusion or report techniques

You receive the stage ({{STAGE}}: conclude for step 7, report for step 8), the brief, the stakes, a short description of the findings (step 7) or the conclusions (step 8), and a list of the eligible techniques, one line each: ID | name | purpose | use when. The list is in score order. The score changes the order only.

Choose at most {{LIMIT}} techniques (3 for conclude, 4 for report). Choosing none is allowed when nothing on the list fits. Use these criteria in order:

1. The technique fits what the findings or conclusions are like, for example numbers or words, one technique or several, an option ranking or a description.
2. The technique does something the fixed part of the step does not already do. The fixed part of step 7 is the agreement table, the narrative summary, pooling of estimates when the user confirmed it, decision analysis when an option ranking is wanted, and the confidence rule. The fixed part of step 8 is the seven parts of the answer and their fixed words.
3. The technique does not need outside material that the brief does not hold and that cannot be looked up. Audience information, decision information and a panel come from the brief. Skip any technique that needs one that is missing, and name it in the dropped list with the reason. A reference structure can be looked up: it is taken from the user's material, or one item is found from any source type and recorded with its type, as in step 5.2. Do not drop a technique only because it needs a reference structure.
4. Report stage only: choose a recommendation technique (family RA) only when the request asks for recommendations or names an audience. Choose a display technique (families VD and RU) only when the answer shows numbers or charts.
5. Where two techniques do the same job, choose one.

For each chosen technique give a one-line reason that names what it changes in the conclusions or the answer.

Write JSON to the output path: {"picks": [{"id": "...", "reason": "..."}], "dropped": [{"id": "...", "reason": "..."}]}.

Rules: choose only IDs that appear in the list. Use Australian English, sentence case, no dashes of any kind, no double hyphens. Work from the description and the list only. Do not read any other file in the working directory.
