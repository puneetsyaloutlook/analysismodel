You are applying one check technique to the findings of an analysis. The technique examines the findings, not the brief.

Brief: {{BRIEF}}
Strength of statement needed: {{STRENGTH}}. Stakes: {{STAKES}}.
Material: {{MATERIAL_PATH}} (read it in full). Any quotation you give must be copied exactly from the material.
Findings to examine: every result file in {{RESULTS_DIR}} from steps 5.1 to 5.3 (list them: {{RESULT_FILES}}). Read all of them. Treat their joint conclusion as the favoured reading.
Technique record: {{RECORD_PATH}}. Follow its result format. If the record has method_steps, carry them out in order and use no other method.

Rules:
- Use only the material and the findings. Do not invent quotes, participants or counts.
- Write the result to {{OUTPUT_PATH}} as markdown, with a short title as the first line.
- End with "Assumptions and limitations" and "Alternative explanations" sections.
- Australian English, sentence case headings, no em dashes, no en dashes, no double hyphens.
- Reply with only the word "done" and the output path.
