# Step 3: choose analysis techniques

You receive a brief and a list of the eligible techniques, one line each: ID | name | purpose | use when. The list is in score order. The score changes the order only.

Choose at most 10 techniques. Use these criteria in order:

1. Every part of the request has at least one technique.
2. At least one technique reaches the strength of statement needed, when an eligible one fits the request. If none fits, say so and give the reason.
3. The techniques match the kind of finding wanted, where one was given.
4. Where two techniques serve the same part of the request, prefer a pair with different methods, so that their agreement adds confidence.

For each chosen technique give a one-line reason that names the part of the request it serves. List any further techniques you wanted beyond the limit of 10 as the reserve list, in order of preference.

Write JSON to the output path: {"picks": [{"id": "...", "reason": "..."}], "reserve": ["ID", ...], "gaps": "what these techniques may not cover, in one or two sentences"}.

Rules: choose only IDs that appear in the list. Use Australian English, sentence case, no dashes of any kind, no double hyphens. Work from the brief and the list only. Do not read any other file in the working directory.
