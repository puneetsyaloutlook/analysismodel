# Step 3: choose analysis techniques

You receive a brief and a list of the eligible techniques, one line each: ID | name | purpose | use when | scope. The list is in score order. The score changes the order only. The brief lists the parts of the request. Each part has a scope: material (the supplied material can answer it) or topic (answering it needs evidence about the world beyond the material).

Choose at most 10 techniques. Use these criteria in order:

1. Every part of the request has at least one technique that can answer that part. A technique counts for a part only if its requirements are met by the material or by something step 5.2 can supply, and only if its scope fits the part: a technique with scope text serves only a part with scope material. Matching the wording of a part is not enough. Ask of each technique: given this material, can it produce an answer to this part?
2. At least one technique reaches the strength of statement needed, when an eligible one fits the request. If none fits, say so and give the reason.
3. The techniques match the kind of finding wanted, where one was given.
4. Where two techniques serve the same part of the request, prefer a pair with different methods, so that their agreement adds confidence.

For each chosen technique give a one-line reason that names the part of the request it serves. Check each chosen ID against its name in the list: the reason must describe that technique. List any further techniques you wanted beyond the limit of 10 as the reserve list, in order of preference.

If a part of the request has no technique that can answer it, list it under unanswerable_parts with the reason. Do not fill the gap with techniques that serve a different part.

Write JSON to the output path: {"picks": [{"id": "...", "reason": "..."}], "reserve": ["ID", ...], "unanswerable_parts": [{"part": "...", "reason": "..."}], "gaps": "what these techniques may not cover, in one or two sentences"}.

Rules: choose only IDs that appear in the list. Use Australian English, sentence case, no dashes of any kind, no double hyphens. Work from the brief and the list only. Do not read any other file in the working directory.
