You are doing step 8 (answer) of an analysis. The answer is the only output the user receives and must be complete without the work.

Brief: {{BRIEF}}
Strength of statement needed: {{STRENGTH}}. Stakes: {{STAKES}}.
Read {{SYNTHESIS_PATH}} (step 7 conclusions with labels and reasons) and {{MATERIAL_PATH}}. You may read the results in {{RESULTS_DIR}} to check wording. Do not run new analysis.

Write {{OUTPUT_PATH}} as JSON with keys:
- summary: array of 2 to 4 paragraphs, 150 to 300 words in all, that answer the request directly. Write whole sentences of normal length, one idea each, and do not drop words to save space. Use no technique codes, conclusion codes or labels such as C1. Name the hypotheses and the things in the request in full. Order: the direct answer to the request in the first sentence; what the analysis found, in the order a reader needs it; how far to trust it, in plain words, with the main limit; what it leaves open. When no chosen technique reached the strength of statement needed, say so in the first paragraph.
- conclusions: array of {id, title, text, label, reason} from the synthesis, worded for a reader who has not seen the work. Keep the titles, labels and meaning. Do not use codes such as C1 or I1 anywhere in the answer, including the reasons. Where a reason refers to another conclusion, name it in words. In each reason, leave out any sentence that says all the techniques read the same material and used the same model, because the fixed words state that once for the whole answer.
- insights: array of {id, title, expected, found, why_it_matters, label, reason} from the synthesis, reworded the same way. An empty array when the synthesis has none. Do not add recommendations.
- not_covered: array of plain sentences with no label: parts of the request the analysis did not answer, and what the process did not look at or search for, taken from the brief, the synthesis and the facts below. An empty array when there is nothing.
- basis: array of fact lines, with no judgement about whether the material is representative or sufficient: what the user gave (each source, type, size); additional sources used (the item, where it came from, its type, the technique that used it and whether code could check its wording); which techniques ran and what each worked on; techniques dropped and why; files that could not be read; checks done by the process and their figures; checks not done; whether a person reviewed the results; whether the user confirmed the request after 5.1; the method the user chose in step 7. Facts: {{BASIS_FACTS}}
The application works out which techniques reached the strength of statement needed from the catalogue ceilings (python3 -I scripts/sequence.py prints them). Report that in the reply to the user.

Australian English, sentence case, no em dashes, no en dashes, no double hyphens, plain literal wording, no incidental metaphors. Reply with only "done" and the output path.
