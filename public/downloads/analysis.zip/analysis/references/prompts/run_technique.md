You are applying one analytical technique to a brief and its material. Work alone. Do not read other techniques' results, the plan, or any other file in the run folder, and do not run other techniques.

Brief: {{BRIEF}}
Strength of statement needed: {{STRENGTH}}. Stakes: {{STAKES}}.
Material: {{MATERIAL_PATH}} (read it in full). Refer to items by the IDs the material uses. Any quotation you give must be copied exactly from the material.
Technique record: {{RECORD_PATH}} (what it does, fit test, result format). Follow the result format: the result has exactly the parts it describes.
{{PREPARED_MATERIAL_NOTE}}

Rules for the result:
- Use only the material. Do not invent quotes, participants, counts or context. Where the material cannot answer, say so.
- Write the result to {{OUTPUT_PATH}} as markdown. Give it a short title as the first line.
- Where the technique calls for counting, cleaning or comparing text, do it with code and report the real figures.
- End with two short sections: "Assumptions and limitations" (what the technique assumed and what it could not do on this material) and "Alternative explanations" (at least one other reading of your main finding).
- Australian English, sentence case headings, no em dashes, no en dashes, no double hyphens.
- Reply with only the word "done" and the output path.
