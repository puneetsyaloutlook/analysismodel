#!/usr/bin/env python3
"""Plan the analysis sequence (design 1.2.3, step 4).
Usage: python3 -I sequence.py CATALOGUE.csv SCHEMA.json JOB.json PICKS.json PASSED.json [--json PLAN.json]
Four groups in running order: Clarify the question (5.1), Prepare the content (5.2), Analyse the content (5.3) and
Test the findings (step 6). Each technique's kind decides its group. The plan describes what each technique does and
whether it needs an additional source. Step 4 only records that need. Step 5.2 resolves it.
Adds de-identification (PE-14) when the material has personal information, and any technique that produces
prepared material a pick needs.
"""
import csv, json, sys, re

args = [a for a in sys.argv[1:]]
json_out = None
if '--json' in args:
    k = args.index('--json'); json_out = args[k + 1]; del args[k:k + 2]
cat, sch, jobf, picksf, passedf = args[:5]
rows = {r['id']: r for r in csv.DictReader(open(cat, encoding='utf-8'))}
schema = json.load(open(sch, encoding='utf-8'))
job = json.load(open(jobf)); picks = [p['id'] for p in json.load(open(picksf))['picks']]
passed = set(json.load(open(passedf)))
kind = {a['name']: a['kind'] for a in schema['artefact_types']}
tier = job['stakes_tier']
INIT = {'charter or question:agreed', 'raw dataset or corpus:raw'}
nm = lambda i: re.sub(r'\*|\(.*|Also serves.*', '', rows[i]['technique']).strip()[:48]

def items(cell): return [x.strip() for x in cell.split(';') if x.strip()]
CAP = 10
allp = list(dict.fromkeys(picks)); chosen = allp[:CAP]; held = allp[CAP:]; added = []
# privacy step
if job['material_profile'].get('privacy') in ('personal information', 'sensitive information') and 'PE-14' in passed and 'PE-14' not in chosen:
    chosen.append('PE-14'); added.append(('PE-14', 'the material holds personal information'))
# upstream producers of prepared material
produced = {a for i in chosen for a in items(rows[i]['produces'])}
for i in list(chosen):
    for a in items(rows[i]['consumes']):
        if a in INIT or a in produced or kind.get(a.split(':')[0]) != 'prepared material':
            continue
        cands = sorted([j for j in passed if a in items(rows[j]['produces']) and j not in chosen and rows[j]['primary_phase'] in ('gather', 'verify and prepare')])
        if cands:
            chosen.append(cands[0]); added.append((cands[0], f"{i} needs {a}; alternatives: {', '.join(cands[1:4]) or 'none'}"))
            produced |= set(items(rows[cands[0]]['produces']))
        elif a.startswith('evidence base') and job.get('outside_evidence') == 'yes':
            added.append(('EVIDENCE', f"{i} needs {a}; 5.2 gathers an evidence base for the parts with scope topic"))
        else:
            added.append((None, f"{i} needs {a}; no technique that passes the gates produces it"))
stage = lambda i: 1 if rows[i]['primary_phase'] in ('gather', 'verify and prepare') else 3 if rows[i]['primary_phase'] == 'validate' else 0 if rows[i]['primary_phase'] == 'frame' else 2
names = {0: 'Clarify the question', 1: 'Prepare the content', 2: 'Analyse the content', 3: 'Test the findings'}
substep = {0: '5.1', 1: '5.2', 2: '5.3', 3: '6'}
plan = {'name': job['name'], 'claim_level_needed': job['claim_level_needed'], 'stakes': tier, 'groups': []}
print(f"# {job['name']}\nClaim level needed: {job['claim_level_needed']}. Stakes: {tier}.\n")
print("Check each name below against the reason recorded for that pick. A name that does not match its reason means a wrong ID: fix picks.json and run this step again.\n")
unans = json.load(open(picksf)).get('unanswerable_parts', [])
plan['unanswerable_parts'] = unans
if unans:
    print('## Parts the material cannot answer')
    for u in unans:
        print(f"- {u.get('part', '')}: {u.get('reason', '')}")
    print('Ask the user one question: add outside evidence, edit the request, or continue without these parts. With no reply, continue without them and say in the first paragraph of the answer which parts were not answered.\n')
if any(j == 'EVIDENCE' for j, w in added):
    print('## Evidence base (5.2)')
    print('- The parts with scope topic need outside evidence. 5.2 gathers it with references/prompts/gather_evidence.md, from any source type, and records each source in evidence_base.json with its type, how it was read and what it is used to show.\n')
for s in range(4):
    ids = sorted(i for i in chosen if stage(i) == s)
    if not ids: continue
    print(f"## {names[s]} ({substep[s]})")
    g = {'position': s + 1, 'group_name': names[s], 'step': substep[s], 'techniques': []}
    for i in ids:
        why = next((w for j, w in added if j == i), '')
        e = rows[i]['external_material_needed'].strip()
        print(f"- {i} {nm(i)}{' (added: ' + why + ')' if why else ''}{' [needs an additional source: ' + e + ']' if e not in ('', 'none') else ''}")
        g['techniques'].append({'id': i, 'name': nm(i), 'purpose': rows[i]['purpose'].strip(), 'external': e or 'none', 'added': why})
    plan['groups'].append(g)
    print()
ext = [(i, rows[i]['external_material_needed'].strip()) for i in sorted(chosen) if rows[i]['external_material_needed'].strip() not in ('', 'none')]
if ext:
    print('## Additional sources (resolved in 5.2, after this plan; nothing is gathered in step 4)')
    for i, e in ext:
        print(f"- {i} needs a {e}. In 5.2: look in the user's material first. If it is not there, find the one item needed, from any source type, and ask the user for it only if none is found. Use it and record the item, its source, its type, the technique and whether code could check its wording. No approval is asked. If none is found, drop {i} and say so.")
    print()
plan['additional_sources'] = [{'id': i, 'needs': e} for i, e in ext]
PERSON = {c['code'] for c in schema['check_library'] if c.get('human_involvement', {}).get('level') in ('needed', 'conditional')}
HIGH = tier == 'high-stakes'
def checks_for(i):
    allc = [c.split(':', 1)[1] for c in items(rows[i]['minimum_checks']) if c.startswith(tier + ':')]
    return [c for c in allc if HIGH or c not in PERSON], [c for c in allc if not HIGH and c in PERSON]
print('## Checks by stakes tier, applied to each analysis result')
left_out = {}
for i in sorted(i for i in chosen if stage(i) == 2):
    keep, drop = checks_for(i)
    if drop: left_out[i] = drop
    print(f"- {i}: {', '.join(keep)}")
print()
if left_out:
    print('Left out below high stakes (they need a person): ' + '; '.join(f"{i}: {', '.join(v)}" for i, v in left_out.items()) + '.\n')
print('Spot check: run spot_check.py where the material lists quotes as Q1 (P1): "...". Otherwise re-read the source against ten quotations taken from the results and record how many were found exactly.\n')
print('## Pause after step 6 (high stakes only)\nIf a chosen technique has a check that needs a person, show a small sample of the results with the labels or findings the model produced, and ask the user to review it, skip it or defer it. Skipped or deferred: list the check as not done and limit the confidence label to medium. Below high stakes this pause does not happen.\n')
print('## Pause after 5.1\nIf a question technique produced findings, show them and ask the user to keep or edit the request. Edit: run steps 2 to 4 again. No reply: keep the request and say in the answer that it was not confirmed.\n')
print('## 7 combine the findings (process step, always last)')
mp = job['material_profile']; ct = set(mp.get('content_type', []))
form = 'mixed' if 'text' in ct and len(ct) > 1 else 'textual' if ct == {'text'} else 'numeric'
opt = 'option ranking' in job.get('insight_wanted', [])
print(f"Findings form: {form}. Methods offered to the user:")
print('- convergence matrix' + (' (recommended: compares the techniques\' findings and marks agreement and dissonance)' if form in ('textual', 'mixed') else ''))
print('- narrative synthesis' + (' (recommended: writes the answer after the matrix)' if form in ('textual', 'mixed') else ''))
print('- quantitative pooling (offered only if the user confirms that two or more findings estimate the same quantity on the same scale)')
if opt: print('- decision analysis and weighting (recommended: the job asks for an option ranking)')
print('Alongside: one confidence label (high, medium or low) and a one-line reason for each conclusion. A fact about the text (what it contains or lacks, checkable by reading) gets the label none.')
print()
print('## 8 answer: what it is based on (facts only, no judgements about the material)')
print(f"- Material given: {mp.get('source_count', 'unknown')} source(s); content types: {', '.join(mp.get('content_type', [])) or 'unknown'}. Name each source, its type and its size.")
print('- Additional sources used: ' + ('; '.join(f"{e} for {i}" for i, e in ext) + '. Name the item, where it came from, its type, the technique that used it and whether code could check its wording.' if ext else 'none.'))
print('- Techniques run, and what each used: ' + '; '.join(f"{i} ({'the brief and the material' if stage(i) in (0, 1, 2) else 'the findings of the analysis'})" for i in sorted(chosen)) + '.')
need = sorted({c for i in chosen for c in checks_for(i)[0] if c in PERSON})
print('- Checks that need a person: ' + ((', '.join(need) + '. State whether the user reviewed the sample; list each one the user did not review as not done.') if need else 'left out at this stakes level. State that no person reviewed the results.'))
print('- Techniques dropped, and why; files that could not be read.')
print()
print('## Follow-up round (only if the user asks)')
print(('Held back by the limit of %d picks: ' % CAP + ', '.join(held) + '. Offer these first.') if held else 'No picks were held back by the limit of %d.' % CAP)
print('After the user reads the synthesis, offer to reassess (at most 5 more techniques per round). If the user accepts, select again with the gaps, silences and conflicts the synthesis found, leave out techniques already run, run the new ones, and synthesise again.')
print()
miss = [w for j, w in added if j is None]
plan['checks'] = {i: checks_for(i)[0] for i in sorted(i for i in chosen if stage(i) == 2)}
plan['left_out'] = left_out
plan['held'] = held
plan['added'] = [{'id': j, 'why': w} for j, w in added]
if json_out: json.dump(plan, open(json_out, 'w'), ensure_ascii=False, indent=1)
if miss: print('## Unresolved\n' + '\n'.join('- ' + m for m in miss) + '\n')
held = [i for i in chosen if 'held-out test sample:sealed' in items(rows[i]['consumes'])]
if len(held) > 1: print('## Conflict\n- More than one technique consumes the single-use held-out sample: ' + ', '.join(held))
