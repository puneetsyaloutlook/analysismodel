#!/usr/bin/env python3
"""Which chosen techniques reach the strength of statement the user needed, and which conclusions they support.
Usage: python3 -I strength_reached.py CATALOGUE.csv JOB.json PICKS.json SYNTHESIS.json
A technique supports a conclusion when its cell in the agreement table is A or P."""
import csv, json, sys
ORDER = ['describe', 'associate', 'predict without implying cause', 'estimate an intervention effect', 'explain mechanism or counterfactual']
PLAIN = {'describe': 'describe', 'associate': 'show a link between things', 'predict without implying cause': 'predict, without claiming a cause',
         'estimate an intervention effect': 'estimate the effect of an action', 'explain mechanism or counterfactual': 'explain how or why'}
rows = {r['id']: r for r in csv.DictReader(open(sys.argv[1], encoding='utf-8'))}
job = json.load(open(sys.argv[2])); picks = [p['id'] for p in json.load(open(sys.argv[3]))['picks']]
syn = json.load(open(sys.argv[4]))
need = ORDER.index(job['claim_level_needed'])
reach = [i for i in picks if i in rows and rows[i]['claim_ceiling'] in ORDER and ORDER.index(rows[i]['claim_ceiling']) >= need]
sup = [c.get('title') or c['id'] for c in syn['conclusions'] if any(c['cells'].get(i) in ('A', 'P') for i in reach)]
all_sup = len(sup) == len(syn['conclusions'])
print('Strength of statement needed: ' + PLAIN[job['claim_level_needed']])
print('Chosen techniques that can reach it: ' + (', '.join(reach) if reach else 'none'))
print('Conclusions they support: ' + ('all ' + str(len(sup)) if sup and all_sup else '; '.join(sup) if sup else 'none'))
