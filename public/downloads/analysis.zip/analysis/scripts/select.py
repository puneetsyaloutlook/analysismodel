#!/usr/bin/env python3
"""Hard-gate filter over master_tagged.csv.

Usage: python3 -I select.py CATALOGUE.csv JOB.json [--relax gate1,gate2] [--claim-mode cover|exclude]

Claim mode cover (default): the claim ceiling does not remove techniques, because appraisal and
preparation techniques support a stronger final claim. The report counts the techniques that reach it.
Units of analysis are derived where a preparation step can split them (document to claim, record to
variable); such techniques carry a note. Relax no_derive to switch that off. [--top N] [--log LOG.csv]

JOB.json keys: name, material_profile (facet key -> value or list of values),
claim_level_needed, stakes_tier, insight_wanted (list).
Output: shortlist (neutral order, by ID) and a count of exclusions by gate.
The exclusion log lists every removed technique with its gate and reason.
All gate values in the catalogue are inference; use --relax to see what a gate removed.
"""
import csv, json, sys, argparse, collections

ORDER_DEPTH = ['narrative only', 'aggregate tables', 'record-level']
ORDER_CLAIM = ['describe', 'associate', 'predict without implying cause',
               'estimate an intervention effect', 'explain mechanism or counterfactual']
EXACT = ['content_type', 'unit_of_analysis', 'source_count', 'linkage',
         'privacy', 'security_classification', 'licence']
CONDITIONAL = ['representation', 'time_structure', 'collection_basis',
               'volume_class', 'data_condition_flags', 'language']
DERIVABLE = {'document': ['claim', 'source'], 'record': ['variable', 'dataset'],
              'dataset': ['variable'], 'source': ['document']}
INITIAL = {'charter or question:agreed', 'raw dataset or corpus:raw'}


def parse_cell(cell):
    cell = (cell or '').strip()
    if cell == '' or cell.lower() in ('any', 'none'):
        return [], []
    req, pref = [], []
    for item in cell.split(';'):
        item = item.strip()
        if item.startswith('requires='):
            req.append(item[9:].strip())
        elif item.startswith('prefers='):
            pref.append(item[8:].strip())
    return req, pref


def as_list(v):
    if v is None:
        return []
    return v if isinstance(v, list) else [v]


def check_not_for(rule_cell, ctx):
    rule_cell = (rule_cell or '').strip()
    if rule_cell.lower() == 'none' or not rule_cell:
        return None
    for excl in rule_cell.split(';'):
        body = excl.split('::')[0].strip()
        reason = excl.split('::')[1].strip() if '::' in excl else ''
        ok = True
        for clause in body.split('&'):
            if '=' not in clause:
                ok = False
                break
            key, vals = clause.split('=', 1)
            have = {str(x) for x in as_list(ctx.get(key.strip()))}
            want = {x.strip() for x in vals.split('|')}
            if not (have & want):
                ok = False
                break
        if ok:
            return reason or body
    return None


def run(rows, job, relax, top, claim_mode='cover'):
    prof = job['material_profile']
    ctx = dict(prof)
    ctx['claim_level_needed'] = job['claim_level_needed']
    ctx['stakes_tier'] = job['stakes_tier']
    ctx['insight_wanted'] = job.get('insight_wanted', [])
    kept, log, deferred, deferred_pi = [], [], [], []
    PREP = {'data source inventory', 'data dictionary', 'codebook', 'data quality report', 'screening log', 'cleaned dataset',
            'feature set', 'training sample', 'held-out test sample', 'coded corpus', 'entity table', 'evidence base', 'claims register'}
    items = lambda c: [x.strip() for x in c.split(';') if x.strip()]

    def score_row(r, derived, extra=None):
        score = 0
        its = {x.strip() for x in r['insight_type'].split(';')}
        score += 3 * len(its & set(job.get('insight_wanted', [])))
        if r['insight_type'].split(';')[0].strip() in job.get('insight_wanted', []):
            score += 2
        for g in EXACT + CONDITIONAL + ['access_depth']:
            _, pref = parse_cell(r[g])
            if pref and g in prof and set(pref) & {str(x) for x in as_list(prof[g])}:
                score += 1
        score += {'Tested': 2, 'Documented': 1}.get(r['evidence_status'], 0)
        up = [c.strip() for c in r['consumes'].split(';') if c.strip() and c.strip() not in INITIAL]
        if derived:
            up = up + [derived]
        if extra:
            up = up + [extra]
        ext = r.get('external_material_needed', 'none').strip()
        if ext and ext != 'none':
            up = up + ['additional source needed: ' + ext]
        return (r, score, up)

    for r in rows:
        why = None
        derived = None
        waivable = None
        pi_waive = None
        for g in EXACT:
            if g in relax or g not in prof:
                continue
            req, _ = parse_cell(r[g])
            have = {str(x) for x in as_list(prof[g])}
            if g == 'unit_of_analysis' and req and not (set(req) & have):
                via = [d for u in have for d in DERIVABLE.get(u, []) if d in req]
                if via and 'no_derive' not in relax:
                    derived = f"needs {via[0]} level units derived first"
                    continue
            if req and not (set(req) & have):
                if g == 'content_type':
                    waivable = (g, f"requires {' or '.join(req)}; material has {', '.join(map(str, as_list(prof[g])))}")
                    continue
                if g == 'privacy' and 'personal information' in have and 'no_waive' not in relax:
                    pi_waive = (g, f"requires {' or '.join(req)}; material has personal information")
                    continue
                why = (g, f"requires {' or '.join(req)}; material has {', '.join(map(str, as_list(prof[g])))}")
                break
        if not why and 'access_depth' not in relax and 'access_depth' in prof:
            req, _ = parse_cell(r['access_depth'])
            if req:
                need = min(ORDER_DEPTH.index(x) for x in req)
                have = ORDER_DEPTH.index(prof['access_depth'])
                if have < need:
                    why = ('access_depth', f"requires {ORDER_DEPTH[need]}; material has {prof['access_depth']}")
        if not why and 'claim_ceiling' not in relax and claim_mode == 'exclude':
            if ORDER_CLAIM.index(r['claim_ceiling']) < ORDER_CLAIM.index(job['claim_level_needed']):
                why = ('claim_ceiling', f"ceiling {r['claim_ceiling']} is below the claim level needed")
        if not why:
            for g in CONDITIONAL:
                if g in relax or g not in prof:
                    continue
                req, _ = parse_cell(r[g])
                if req and not (set(req) & {str(x) for x in as_list(prof[g])}):
                    if g == 'representation' and 'no_waive' not in relax:
                        waivable = waivable or (g, f"requires {' or '.join(req)}; material has {prof[g]}")
                        continue
                    why = (g, f"requires {' or '.join(req)}; material has {prof[g]}")
                    break
        if not why and 'not_for_rules' not in relax:
            n = check_not_for(r['not_for_rules'], ctx)
            if n:
                why = ('not_for_rules', n)
        if why:
            log.append((r['id'], r['technique'][:50], why[0], why[1]))
            continue
        if pi_waive:
            deferred_pi.append((r, pi_waive, derived, waivable))
            continue
        if waivable and 'no_waive' not in relax:
            deferred.append((r, waivable, derived))
            continue
        if waivable:
            log.append((r['id'], r['technique'][:50], waivable[0], waivable[1]))
            continue
        kept.append(score_row(r, derived))
    # a technique that fails only on content type or representation passes when every prepared artefact it
    # consumes is produced by a technique that passed the gates (repeated until nothing changes)
    produced = {}
    for r, _, _ in kept:
        for a in items(r['produces']):
            produced.setdefault(a, r['id'])
    changed = True
    while deferred and changed:
        changed = False
        for entry in list(deferred):
            r, w, derived = entry
            need = [a for a in items(r['consumes']) if a.split(':')[0] in PREP]
            if need and all(a in produced for a in need):
                kept.append(score_row(r, derived, 'content type or representation met after ' + ', '.join(sorted({produced[a] for a in need})) + ' runs'))
                deferred.remove(entry)
                for a in items(r['produces']):
                    produced.setdefault(a, r['id'])
                changed = True
    for r, w, derived in deferred:
        log.append((r['id'], r['technique'][:50], w[0], w[1]))
    # decision 29: a technique that cannot take personal information is kept, with a note, when de-identification
    # (PE-14) passes and runs before it
    if any(k[0]['id'] == 'PE-14' for k in kept):
        for r, w, derived, other in deferred_pi:
            if other:
                log.append((r['id'], r['technique'][:50], other[0], other[1]))
            else:
                kept.append(score_row(r, derived, 'personal information removed first by PE-14'))
    else:
        for r, w, derived, other in deferred_pi:
            log.append((r['id'], r['technique'][:50], w[0], w[1]))
    kept.sort(key=lambda x: (-x[1], x[0]['id']))
    short = sorted(kept[:top], key=lambda x: x[0]['id'])
    return kept, short, log


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('catalogue'); ap.add_argument('job')
    ap.add_argument('--relax', default=''); ap.add_argument('--top', type=int, default=15)
    ap.add_argument('--log', default='')
    ap.add_argument('--index', default='', help='write the step 3 list: one line per eligible technique, in score order')
    ap.add_argument('--claim-mode', default='cover', choices=['cover', 'exclude'])
    ap.add_argument('--stage', default='analysis', choices=['analysis', 'conclude', 'report'],
                    help='analysis (step 3, the default) leaves out conclude and report techniques; conclude is for step 7; report is for step 8')
    a = ap.parse_args()
    rows = list(csv.DictReader(open(a.catalogue, encoding='utf-8', newline='')))
    if a.stage == 'analysis':
        rows = [r for r in rows if r['primary_phase'] not in ('conclude', 'report')]
    else:
        rows = [r for r in rows if r['primary_phase'] == a.stage]
    job = json.load(open(a.job, encoding='utf-8'))
    relax = {x.strip() for x in a.relax.split(',') if x.strip()}
    kept, short, log = run(rows, job, relax, a.top, a.claim_mode)
    print(f"Job: {job['name']}")
    print(f"Passed all gates: {len(kept)} of {len(rows)}. Shortlist shows the top {a.top} by score, in ID order.")
    by = collections.Counter(g for _, _, g, _ in log)
    print('Removed by gate:', ', '.join(f'{g} {n}' for g, n in by.most_common()))
    need = ORDER_CLAIM.index(job['claim_level_needed'])
    reach = [r['id'] for r, _, _ in kept if ORDER_CLAIM.index(r['claim_ceiling']) >= need]
    if a.claim_mode == 'cover':
        print(f"Techniques reaching the claim level needed ({job['claim_level_needed']}): {len(reach)}"
              + ('' if reach else '  WARNING: none, so the job cannot support that claim'))
    print('Shortlist:')
    for r, s, up in short:
        extra = f" [needs upstream: {'; '.join(up)}]" if up else ''
        print(f"  {r['id']} {r['technique'][:46]} (score {s}){extra}")
    if a.index:
        with open(a.index, 'w', encoding='utf-8') as fh:
            for r, s, up in kept:
                fh.write(f"{r['id']} | {r['technique'].split(' (')[0].strip()} | {r['purpose']} | {r['use_when']}\n")
    if a.log:
        with open(a.log, 'w', newline='', encoding='utf-8') as fh:
            w = csv.writer(fh); w.writerow(['id', 'technique', 'gate', 'reason']); w.writerows(log)
        passed = [r['id'] for r, _, _ in kept]
        json.dump(passed, open(a.log.replace('.csv', '_passed.json'), 'w'))


if __name__ == '__main__':
    main()
