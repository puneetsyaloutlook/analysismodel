#!/usr/bin/env python3
"""Intake: turn a link, pasted content, typed text or a document collection into a brief and a material profile.

Usage:
  python3 -I intake.py profile OUT.json SOURCE [SOURCE ...]
      SOURCE is a file, a folder, or a text file saved from a link or from pasted text.
      Optional sidecar: SOURCE.meta.json with keys origin_type (link|pasted|typed|file),
      url, title, author, publisher, date, fetched_by (WebFetch when a page was read by a tool).
  python3 -I intake.py gaps PROFILE.json BRIEF.json OUT_JOB.json OUT_QUESTIONS.json
      BRIEF.json holds question, claim_level_needed, stakes_tier, insight_wanted, each as
      {"value": ..., "basis": "stated|inferred|missing"}, plus optional profile overrides
      {"overrides": {facet: value}} from the user's answers. It also holds "parts": a list of
      {"text": "...", "scope": {"value": "material|topic", "basis": "stated|inferred"}} (the request split into
      parts; scope material means the supplied material can answer the part, scope topic means answering it needs
      evidence about the world beyond the material), and optionally "scope_answer" ("accept", "material" or "topic"
      from the user's answer to the scope question) and "outside_evidence" ("yes" or "no").

The profile step records what code can see. A model fills source metadata for links and pasted text.
Anything not shown by the material is left as unknown and goes to the gap step.
"""
import sys, os, re, json, hashlib, subprocess, csv, zipfile, collections

STOP = set("the of and to a in is that it for was on with as be this are at by not or from have an but they you we i he she were which their has had one all would there been if more when will who so what out about up can said no my me do how its than them into then also very just like um uh yeah okay".split())
SPEAKER = re.compile(r'^\s*(?:\[?[A-Z][A-Za-z0-9 ]{0,24}\]?|P\d+|Q|A)\s*[:\-]\s+\S', re.M)
TIMESTAMP = re.compile(r'(?:^|\s|\[)(\d{1,2}:\d{2}(?::\d{2})?)(?:\]|\s)')
EMAIL = re.compile(r'[\w.+-]+@[\w-]+\.[\w.-]+')
PHONE = re.compile(r'(?<!\d)(?:\+?61|0)[2-478](?:[ -]?\d){8}(?!\d)')
YEAR = re.compile(r'\b(19[89]\d|20[0-3]\d)\b')
SENSITIVE_WORDS = ['diagnos', 'medication', 'mental health', 'religio', 'sexual', 'ethnic', 'criminal', 'convict', 'union member', 'disabilit', 'immigration', 'visa status']
GENRE_HINTS = [
    ('research article', [r'\babstract\b', r'\breferences\b', r'\bmethods?\b', r'\bdoi\b']),
    ('legal or regulatory text', [r'\bsection \d+', r'\bshall\b', r'\bact \d{4}', r'\bregulation\b']),
    ('government or agency report', [r'\bexecutive summary\b', r'\brecommendations?\b', r'\bdepartment of\b', r'\bcommission\b']),
    ('news or commentary', [r'\bopinion\b', r'\bby [A-Z][a-z]+ [A-Z][a-z]+\b', r'\bpublished\b']),
]


def read_text(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        if ext in ('.txt', '.md', '.json', '.vtt', '.srt', '.log'):
            return open(path, encoding='utf-8', errors='replace').read(), 'text'
        if ext in ('.html', '.htm'):
            from bs4 import BeautifulSoup
            return BeautifulSoup(open(path, encoding='utf-8', errors='replace').read(), 'html.parser').get_text('\n'), 'text'
        if ext == '.docx':
            import docx
            return '\n'.join(p.text for p in docx.Document(path).paragraphs), 'text'
        if ext == '.pdf':
            out = subprocess.run(['pdftotext', '-layout', path, '-'], capture_output=True, text=True, timeout=60)
            return out.stdout, 'text'
        if ext in ('.csv', '.tsv'):
            return open(path, encoding='utf-8', errors='replace').read(), 'tabular'
        if ext in ('.xlsx', '.xlsm'):
            import openpyxl
            wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
            lines = []
            for ws in wb.worksheets:
                for row in ws.iter_rows(values_only=True):
                    lines.append('\t'.join('' if v is None else str(v) for v in row))
            return '\n'.join(lines), 'tabular'
    except Exception as e:
        return '', 'error:' + str(e)[:80]
    return '', 'unsupported'


def words(text):
    return re.findall(r"[A-Za-z']+", text)


def english_share(text):
    w = [x.lower() for x in words(text)]
    if len(w) < 20:
        return None
    return sum(1 for x in w if x in STOP) / len(w)


def nonlatin_share(text):
    letters = [c for c in text if c.isalpha()]
    if not letters:
        return 0.0
    return sum(1 for c in letters if ord(c) > 0x024F) / len(letters)


def tabular_stats(text):
    rows = list(csv.reader(text.splitlines(), delimiter='\t' if text.count('\t') > text.count(',') else ','))
    rows = [r for r in rows if r]
    if len(rows) < 2:
        return None
    width = collections.Counter(len(r) for r in rows).most_common(1)[0][0]
    cells = [c for r in rows[1:] for c in r]
    blank = sum(1 for c in cells if not c.strip()) / max(1, len(cells))
    num = sum(1 for c in cells if re.fullmatch(r'-?[\d,]*\.?\d+%?', c.strip() or 'x')) / max(1, len(cells))
    return {'rows': len(rows) - 1, 'columns': width, 'blank_share': round(blank, 3), 'numeric_share': round(num, 3)}


def shingles(text, k=5):
    w = [x.lower() for x in words(text)]
    return {' '.join(w[i:i + k]) for i in range(max(1, len(w) - k + 1))}


def profile_source(path, meta, idx):
    text, kind = read_text(path)
    s = {'source_id': 'S%d' % idx, 'file': os.path.basename(path), 'read_status': 'ok' if text else kind or 'empty',
         'origin_type': meta.get('origin_type', 'file'), 'metadata': {k: meta[k] for k in ('url', 'title', 'author', 'publisher', 'date', 'fetched_by') if k in meta}}
    s['_text'] = text
    flags = []
    if not text:
        s['facets'] = {}
        s['flags'] = ['no readable text: ' + (kind or 'empty')]
        return s
    w = words(text)
    f = {}
    s['stats'] = {'words': len(w), 'characters': len(text), 'lines': text.count('\n') + 1}
    if kind == 'tabular':
        ts = tabular_stats(text)
        f['content_type'] = ['tabular']
        f['representation'] = 'structured'
        f['unit_of_analysis'] = ['record', 'variable', 'dataset']
        f['access_depth'] = 'record-level'
        if ts:
            s['stats'].update(ts)
            if ts['blank_share'] > 0.05:
                flags.append('missing data')
    else:
        f['content_type'] = ['text']
        f['representation'] = 'unstructured'
        f['unit_of_analysis'] = ['document', 'claim', 'topic']
        f['access_depth'] = 'narrative only'
        lines = [l for l in text.splitlines() if l.strip()]
        sp = len(SPEAKER.findall(text)) / max(1, len(lines))
        ts_hits = len(TIMESTAMP.findall(text))
        s['stats']['speaker_label_share'] = round(sp, 2)
        genre = None
        if sp > 0.25 or (ts_hits > 5 and sp > 0.1):
            genre = 'transcript or testimony'
            f['representation'] = 'semi-structured'
        else:
            low = text.lower()
            best = max(GENRE_HINTS, key=lambda g: sum(1 for p in g[1] if re.search(p, low)))
            if sum(1 for p in best[1] if re.search(p, low)) >= 2:
                genre = best[0]
        f['document_genre'] = genre or 'unknown'
        if f['document_genre'] == 'unknown':
            s.setdefault('suggest_ask', []).append('document_genre')
    es = english_share(text)
    nl = nonlatin_share(text)
    if es is None:
        f['language'] = 'unknown'
    elif nl > 0.1:
        f['language'] = 'multiple'
        flags.append('non-Latin script share %.0f%%' % (nl * 100))
    elif es > 0.18:
        f['language'] = 'single'
        s['language_note'] = 'English by stopword share'
    else:
        f['language'] = 'unknown'
        flags.append('low English stopword share, language unconfirmed')
    emails, phones = EMAIL.findall(text), PHONE.findall(text)
    sens = [x for x in SENSITIVE_WORDS if x in text.lower()]
    pi = []
    if emails: pi.append('%d email addresses' % len(emails))
    if phones: pi.append('%d phone numbers' % len(phones))
    if f.get('document_genre') == 'transcript or testimony': pi.append('speakers in a transcript')
    s['personal_information_signals'] = pi
    s['sensitive_word_hits'] = sens
    f['privacy'] = 'sensitive information' if sens else ('personal information' if pi else 'unknown')
    if f['privacy'] == 'unknown' and f.get('document_genre') in ('research article', 'government or agency report', 'legal or regulatory text', 'news or commentary'):
        f['privacy'] = 'no personal information'
        s['privacy_basis'] = 'inferred: report-type document with no emails, phone numbers or sensitive words'
    years = [int(y) for y in YEAR.findall(text)]
    if years:
        s['latest_year_mentioned'] = max(years)
    f['volume_class'] = 'readable by a person' if len(w) < 60000 else 'needs automation'
    f['time_structure'] = 'not applicable' if kind != 'tabular' else 'unknown'
    f['collection_basis'] = 'unknown'
    m = s['metadata']
    if 'url' in m:
        f['origin'] = 'unknown'
        if re.search(r'\.gov(\.[a-z]{2})?(/|$)', m['url']):
            f['document_genre'] = f.get('document_genre') if f.get('document_genre') != 'unknown' else 'government or agency report'
        if m.get('fetched_by') == 'WebFetch':
            flags.append('read through a page fetch tool that may summarise long pages: quotes unverified against the page')
    s['facets'] = f
    s['flags'] = flags
    return s


def collect(paths):
    items = []
    for p in paths:
        if os.path.isdir(p):
            for root, _, files in os.walk(p):
                for fn in sorted(files):
                    if not fn.endswith('.meta.json') and not fn.startswith('.'):
                        items.append(os.path.join(root, fn))
        else:
            items.append(p)
    return items


def cmd_profile(out, paths):
    files = collect(paths)
    sources = []
    for i, p in enumerate(files, 1):
        meta = {}
        if os.path.exists(p + '.meta.json'):
            meta = json.load(open(p + '.meta.json'))
        sources.append(profile_source(p, meta, i))
    # duplicates
    sh = [(s['source_id'], shingles(s['_text'])) for s in sources if s.get('_text')]
    dup = []
    for i in range(len(sh)):
        for j in range(i + 1, len(sh)):
            a, b = sh[i][1], sh[j][1]
            if a and b and len(a & b) / len(a | b) > 0.9:
                dup.append([sh[i][0], sh[j][0]])
    typed_q = None
    keep = []
    for s in sources:
        if s['origin_type'] == 'typed' and s.get('stats', {}).get('words', 99) < 40:
            typed_q = s['_text'].strip()
            continue
        keep.append(s)
    sources = keep
    for s in sources:
        s.pop('_text', None)
    ok = [s for s in sources if s.get('facets')]
    kinds = {t for s in ok for t in s['facets'].get('content_type', [])}
    coll = {
        'content_type': sorted(kinds),
        'unit_of_analysis': sorted({u for s in ok for u in s['facets']['unit_of_analysis']} | ({'source'} if len(ok) > 1 else set())),
        'access_depth': min((s['facets']['access_depth'] for s in ok), key=['narrative only', 'aggregate tables', 'record-level'].index) if ok else 'unknown',
        'source_count': 'one' if len(ok) <= 1 else 'two or more',
        'linkage': 'not applicable' if len(ok) <= 1 else 'unknown',
        'volume_class': 'needs automation' if any(s['facets']['volume_class'] == 'needs automation' for s in ok) or len(ok) > 40 else 'readable by a person',
        'representation': ('unknown' if not ok else (sorted({s['facets']['representation'] for s in ok})[0] if len({s['facets']['representation'] for s in ok}) == 1 else 'semi-structured')),
        'language': 'unknown' if not ok else 'single' if all(s['facets']['language'] == 'single' for s in ok) else ('multiple' if any(s['facets']['language'] == 'multiple' for s in ok) else 'unknown'),
        'privacy': 'unknown',
        'security_classification': 'unknown',
        'licence': 'unknown',
        'data_condition_flags': [],
    }
    order = ['no personal information', 'unknown', 'personal information', 'sensitive information']
    pv = [s['facets']['privacy'] for s in ok]
    if pv:
        coll['privacy'] = max(pv, key=order.index)
        if coll['privacy'] == 'unknown' and not any(s.get('sensitive_word_hits') for s in ok):
            coll['privacy'] = 'unknown'
    notes = {}
    if any(s.get('privacy_basis') for s in ok) and coll['privacy'] == 'no personal information':
        notes['privacy'] = 'inferred from report-type documents with no personal signals'
    flags = set()
    if dup:
        flags.add('duplicated')
    if any('missing data' in s['flags'] for s in ok):
        flags.add('missing data')
    coll['data_condition_flags'] = sorted(flags) or ['unknown']
    json.dump({'typed_question': typed_q, 'sources': sources, 'collection': coll, 'duplicate_pairs': dup, 'inferred_notes': notes,
               'unreadable': [s['file'] for s in sources if not s.get('facets')]}, open(out, 'w'), indent=1, ensure_ascii=False)
    print('%d sources, %d readable, %d duplicate pairs' % (len(sources), len(ok), len(dup)))


CLAIM_WORDS = [
    ('explain mechanism or counterfactual', r'\bwhy\b.*\b(cause|because|mechanism)\b|\bwould have\b|\bcounterfactual\b'),
    ('estimate an intervention effect', r'\beffect of\b|\bimpact of\b|\bdid .* (reduce|increase|improve)\b|\bintervention\b'),
    ('predict without implying cause', r'\bforecast\b|\bpredict\b|\bwill\b.*\b(next|in 20\d\d)\b'),
    ('associate', r'\brelationship\b|\bassociat|\bcorrelat|\blinked to\b|\bdrivers?\b|\bhold\b|\bsupport(ed)?\b'),
    ('describe', r'\bwhat\b|\bhow many\b|\bsummar|\bdescribe\b|\bthemes?\b'),
]
INSIGHT_WORDS = {'pattern': r'\bthemes?\b|\bpattern|\btrend\b', 'difference': r'\bdiffer|\bcompare|\bversus\b|\bvs\b', 'contradiction': r'\bconflict|\bcontradict|\bdisagree|\bhold\b', 'cause': r'\bwhy\b|\bcause|\bdriver', 'trend': r'\btrend|\bover time\b|\bchange', 'gap': r'\bgap\b|\bmissing\b|\bnot covered', 'risk': r'\brisk\b|\bthreat', 'option ranking': r'\bwhich (option|one|should)\b|\brank|\bbest\b|\bchoose'}


def suggest_from_question(q):
    q = q.lower()
    claim = None
    for name, pat in CLAIM_WORDS:
        if re.search(pat, q):
            claim = name
            break
    ins = [k for k, p in INSIGHT_WORDS.items() if re.search(p, q)]
    return claim, ins


TOPIC_WORDS = re.compile(r'\baccurate(ly)?\b|\bis it (true|correct|right)\b|\bphenomenon\b|\bin practice\b|\bhow (common|often|many|much)\b|\bdoes .* (work|predict|cause)\b|\bevidence (for|that)\b|\bdiagnos|\breally\b|\btrue of\b|\bwhat is happening\b|\bhow do (organisations|companies|people)\b', re.I)


def cmd_gaps(profile_path, brief_path, out_job, out_q):
    prof = json.load(open(profile_path))
    brief = json.load(open(brief_path))
    coll = dict(prof['collection'])
    coll.update(brief.get('overrides', {}))
    qs = []
    basis = {}

    def get(key):
        v = brief.get(key) or {}
        return v.get('value'), v.get('basis', 'missing')

    question, qb = get('question')
    if not question and prof.get('typed_question'):
        question, qb = prof['typed_question'], 'stated'
    if not question:
        qs.append({'id': 'question', 'priority': 0, 'header': 'Question', 'question': 'What do you want to find out from this material?',
                   'options': [], 'free_text': True, 'why': 'No question was stated, and the question sets the claim level and the insight wanted.'})
    parts = [dict(p) for p in brief.get('parts', [])]
    if not parts and question:
        parts = [{'text': question, 'scope': {'value': None, 'basis': 'missing'}}]
    for p in parts:
        sc = p.get('scope') or {}
        if not sc.get('value'):
            p['scope'] = {'value': 'topic' if TOPIC_WORDS.search(p['text']) else 'material', 'basis': 'inferred'}
    answer = brief.get('scope_answer')
    if answer in ('material', 'topic'):
        for p in parts:
            p['scope'] = {'value': answer, 'basis': 'stated'}
    elif answer == 'accept':
        for p in parts:
            p['scope']['basis'] = 'stated'
    if parts and any(p['scope'].get('basis') != 'stated' for p in parts):
        shown = '; '.join('%s (%s)' % (p['text'][:90], p['scope']['value']) for p in parts)
        qs.append({'id': 'scope', 'priority': 1, 'header': 'Scope',
                   'question': 'Can the supplied material alone answer each part of the request? Parts and proposed scope: ' + shown,
                   'options': ['accept the scopes shown', 'all parts can be answered from the material', 'all parts need evidence from outside the material'],
                   'recommended': 'accept the scopes shown',
                   'why': 'A part with scope topic needs outside evidence, and the techniques chosen depend on it. Answer with scope_answer in the brief: accept, material or topic.'})
    claim, cb = get('claim_level_needed')
    ins, ib = get('insight_wanted')
    if question and not ins and re.search(r'\binsights?\b|\bwhat can i (learn|get|find)|\btell me what|\bwhat do you (see|make)|\banything (useful|interesting)|\bwhat.s in (this|here)', question.lower()):
        ins, ib = ['open'], 'open request'
    if question:
        sc, si = suggest_from_question(question)
        if not claim and sc:
            claim, cb = sc, 'inferred'
        if not ins and si:
            ins, ib = si, 'inferred'
    if cb != 'stated':
        opts = ['describe', 'associate', 'predict without implying cause', 'estimate an intervention effect', 'explain mechanism or counterfactual']
        rec = claim if claim in opts else 'associate'
        qs.append({'id': 'claim_level_needed', 'priority': 2, 'header': 'Claim level',
                   'question': 'What is the strongest claim you need to make from the result?',
                   'options': ([rec] + [o for o in opts if o != rec])[:4], 'recommended': rec,
                   'why': 'Techniques that cannot support this claim are removed. Inferred from the question wording.' if claim else 'Not stated and not shown by the question.'})
        claim = claim or rec
    stakes, sb = get('stakes_tier')
    if sb != 'stated':
        qs.append({'id': 'stakes_tier', 'priority': 1, 'header': 'Stakes',
                   'question': 'What will the result be used for?',
                   'options': ['decide what to look at next (exploratory)', 'inform a decision (decision-informing)', 'support a decision that is costly or hard to reverse (high-stakes)'],
                   'recommended': 'inform a decision (decision-informing)',
                   'why': 'Sets how many checks the skill runs on each technique.'})
        stakes = stakes or 'decision-informing'
    if ins == ['open']:
        ins = []
        claim = claim or 'describe'
        if cb != 'stated' and not any(q['id'] == 'claim_level_needed' for q in qs):
            pass
    if not ins and ib != 'open request':
        qs.append({'id': 'insight_wanted', 'priority': 3, 'header': 'Insight',
                   'question': 'What kind of finding are you after?',
                   'options': ['pattern', 'difference', 'contradiction', 'gap'], 'multi': True,
                   'why': 'Used to rank techniques that passed the gates.'})
    # material gaps
    if coll.get('privacy') == 'unknown':
        qs.append({'id': 'privacy', 'priority': 2, 'header': 'Personal data',
                   'question': 'Does the material contain information about identifiable people?',
                   'options': ['no personal information', 'personal information', 'sensitive information'], 'recommended': None,
                   'why': 'Code found no signals either way. A wrong answer here lets a technique run that should not.'})
    sens_hits = sorted({w for s in prof['sources'] for w in s.get('sensitive_word_hits', [])})
    if sens_hits and 'privacy' not in brief.get('overrides', {}):
        coll['privacy'] = 'sensitive information'
        basis['privacy'] = 'inferred from words: ' + ', '.join(sens_hits) + ' (confirm)'
    if coll.get('source_count') == 'two or more' and coll.get('linkage') == 'unknown' and 'tabular' in coll.get('content_type', []):
        qs.append({'id': 'linkage', 'priority': 3, 'header': 'Linking',
                   'question': 'Do the data files share an identifier, such as a participant or account number?',
                   'options': ['shared identifier available', 'no shared identifier'], 'why': 'Needed to join tables.'})
    ungenre = [s['source_id'] for s in prof['sources'] if s.get('facets', {}).get('document_genre') == 'unknown']
    if prof.get('unreadable'):
        qs.append({'id': 'unreadable', 'priority': 0, 'header': 'Unreadable',
                   'question': 'These files could not be read: %s. Paste the text or upload another format?' % ', '.join(prof['unreadable']),
                   'options': ['paste the text', 'skip them'], 'why': 'They are not in the profile.'})
    if prof.get('duplicate_pairs'):
        qs.append({'id': 'duplicates', 'priority': 3, 'header': 'Duplicates',
                   'question': 'These sources look the same: %s. Count each once?' % '; '.join('%s and %s' % tuple(p) for p in prof['duplicate_pairs']),
                   'options': ['yes, count once', 'no, they are separate'], 'recommended': 'yes, count once', 'why': 'Duplicates inflate agreement in cross-source techniques.'})
    if not [s for s in prof['sources'] if s.get('facets')]:
        qs.append({'id': 'material', 'priority': 0, 'header': 'Material',
                   'question': 'What material should the analysis use? Paste text, give a link, or upload files.',
                   'options': [], 'free_text': True, 'why': 'No readable material is in the profile.'})
    qs.sort(key=lambda x: x['priority'])
    ask, later = qs[:4], qs[4:]
    job = {'name': (question or 'untitled')[:60],
           'question': question,
           'material_profile': coll,
           'claim_level_needed': claim, 'stakes_tier': stakes, 'insight_wanted': ins or [],
           'parts': parts,
           'topic_parts': sum(1 for p in parts if p['scope']['value'] == 'topic'),
           'outside_evidence': brief.get('outside_evidence', 'unknown'),
           'basis': {'question': qb, 'claim_level_needed': cb, 'stakes_tier': sb, 'insight_wanted': ib, **prof.get('inferred_notes', {}), **basis},
           'unconfirmed': [q['id'] for q in qs]}
    json.dump(job, open(out_job, 'w'), indent=1, ensure_ascii=False)
    json.dump({'ask_now': ask, 'ask_if_needed_later': later}, open(out_q, 'w'), indent=1, ensure_ascii=False)
    print('%d questions to ask now, %d held back' % (len(ask), len(later)))


if __name__ == '__main__':
    a = sys.argv[1:]
    if len(a) >= 2 and a[0] == 'profile':
        cmd_profile(a[1], a[2:])
    elif len(a) == 5 and a[0] == 'gaps':
        cmd_gaps(*a[1:])
    else:
        print(__doc__)
        sys.exit(2)
