#!/usr/bin/env python3
"""Source-span check by code (technique CK-17). Every double-quoted span in a result must appear in the source
(string match after lower-casing and removing punctuation). A span with an ellipsis is split and each part is checked.
Usage: python3 -I source_span_check.py SOURCE.md RESULTS_DIR OUT.json
Spans that are labels or terms in quotation marks fail too; report them as failed and say what they are."""
import re, sys, json, glob, os
def norm(s): return re.sub(r'\s+', ' ', re.sub(r"[^a-z0-9' ]+", ' ', s.lower().replace('’', "'"))).strip()
src = norm(open(sys.argv[1], encoding='utf-8').read())
out = {}
for f in sorted(glob.glob(os.path.join(sys.argv[2], '*.md'))):
    t = open(f, encoding='utf-8').read(); res = []
    for s in re.findall(r'"([^"\n]{3,}?)"', t):
        parts = [p for p in re.split(r'\.\.\.|…', s) if norm(p)]
        res.append((s, all(norm(p) in src for p in parts)))
    out[os.path.basename(f)[:-3]] = res
json.dump(out, open(sys.argv[3], 'w'), indent=1)
tot = sum(len(v) for v in out.values()); bad = [(k, s) for k, v in out.items() for s, o in v if not o]
print('spans checked', tot, 'failed', len(bad))
for k, s in bad: print(k, '|', s)
