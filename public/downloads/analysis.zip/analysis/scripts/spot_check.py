#!/usr/bin/env python3
"""Spot check by code. Applies to interview material whose quotes are listed as lines like 'Q3 (P2): "..."'.
In each result, every sentence or table cell that names one quote and one participant must pair them as the source does.
Usage: python3 -I spot_check.py SOURCE.md RESULTS_DIR OUT.json
Prints 'not applicable' when the source has no such lines; then do the spot check by re-reading the source instead."""
import re, glob, json, sys, os
src = open(sys.argv[1], encoding='utf-8').read()
pair = {f'Q{q}': f'P{p}' for q, p in re.findall(r'^Q(\d+) \(P(\d+)\):', src, flags=re.M)}
if not pair:
    print('not applicable: no lines like Q1 (P1): in the source'); sys.exit(0)
out = {}
for f in sorted(glob.glob(os.path.join(sys.argv[2], '*.md'))):
    checked = 0; bad = []
    for ln, line in enumerate(open(f, encoding='utf-8'), 1):
        for chunk in re.split(r'(?<=[.;:])\s+|\|', line):
            qs = re.findall(r'\bQ(\d+)\b', chunk); ps = re.findall(r'\bP(\d+)\b', chunk)
            if len(qs) == 1 and len(ps) == 1:
                checked += 1
                if pair.get(f'Q{qs[0]}') != f'P{ps[0]}': bad.append((ln, chunk.strip()[:140]))
        for q in re.findall(r'\bQ(\d+)\b', line):
            if f'Q{q}' not in pair: bad.append((ln, f'Q{q} is not in the source'))
    out[os.path.basename(f)[:-3]] = {'pairs_checked': checked, 'mismatches': bad}
json.dump(out, open(sys.argv[3], 'w'), indent=1)
for k, v in out.items(): print(k, 'pairs checked', v['pairs_checked'], 'mismatches', len(v['mismatches']))
