#!/usr/bin/env python3
"""Print the record of one technique for an agent: id, name, what it does, fit test, use when, result format,
minimum needs, additional sources needed and the typical failure.
Usage: python3 -I technique_record.py CATALOGUE.csv ID > record.txt"""
import csv, sys
rows = {r['id']: r for r in csv.DictReader(open(sys.argv[1], encoding='utf-8'))}
r = rows[sys.argv[2]]
for k, label in [('id', 'id'), ('technique', 'technique'), ('what_it_does', 'what_it_does'), ('fit_test', 'fit_test'),
                 ('use_when', 'use_when'), ('output_spec', 'output_spec'), ('requires_minimum', 'requires_minimum'),
                 ('external_material_needed', 'external_material_needed'), ('typical_model_failure', 'typical_model_failure')]:
    print(f'{label}: {r[k]}')
